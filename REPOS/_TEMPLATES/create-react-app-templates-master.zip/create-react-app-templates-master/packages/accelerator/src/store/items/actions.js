export function addItem(text) {
  return { type: 'ADD_ITEM', text };
}
