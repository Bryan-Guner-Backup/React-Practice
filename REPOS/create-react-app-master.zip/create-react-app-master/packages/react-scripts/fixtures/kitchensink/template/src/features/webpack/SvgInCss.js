import React from 'react';
import './assets/svg.css';

const SvgInCss = () => <div id="feature-svg-in-css" />;

export default SvgInCss;
